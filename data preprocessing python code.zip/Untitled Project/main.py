import pandas as pd

# Load raw data
data = pd.read_csv('data/raw_data.csv')

# Handle missing values
data.fillna(data.mean(), inplace=True)

# Convert categorical variables to numeric
data = pd.get_dummies(data, drop_first=True)

# Save preprocessed data
data.to_csv('data/preprocessed_data.csv', index=False)

# Convert to ARFF format (if necessary, use a library or manual conversion)